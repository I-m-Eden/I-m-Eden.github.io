#pragma once
#ifndef H_HEAD
#define H_HEAD
#include <ctime>
#include <map>
#include <cmath>
#include <string>
#include <iostream>
#include <algorithm>
#include <utility>
#include <afxwin.h>
#include <windows.h>
#include <fstream>
using namespace std;
#endif