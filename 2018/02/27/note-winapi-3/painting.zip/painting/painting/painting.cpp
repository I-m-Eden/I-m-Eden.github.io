#include <Windows.h>
const char TITLE[] = "Painting";
const char CLASSNAME[] = "painting";
const HANDLE hnullbrush = GetStockObject(NULL_BRUSH);
const HANDLE hnullpen = GetStockObject(NULL_PEN);
HBRUSH hbrush;
HPEN hpen;
LRESULT CALLBACK WndProc(HWND hwnd, UINT umsg, WPARAM wparam, LPARAM lparam) {
	switch (umsg) {
	case WM_DESTROY: PostQuitMessage(0); break;
	}
	return DefWindowProc(hwnd, umsg, wparam, lparam);
}
ATOM MyRegisterClass(HINSTANCE hInstance) {
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = CLASSNAME;
	wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	return RegisterClassEx(&wcex);
}
int WINAPI WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevinstance,
	LPSTR lpCmdline,
	int nCmdshow
) {
	if (hPrevinstance) {
		MessageBox(NULL, "Ӧ�ó�����������", "ע��", MB_OK);
		return 0;
	}
	if (!MyRegisterClass(hInstance)) {
		MessageBox(NULL, "ע�ᴰ��ʧ��", "����", MB_OK);
		return 0;
	}
	RECT rect = { 0, 0, 640, 480 };
	AdjustWindowRectEx(&rect, WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0);
	HWND hwnd = CreateWindowEx(
		NULL,
		CLASSNAME, TITLE,
		WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		CW_USEDEFAULT, CW_USEDEFAULT, rect.right-rect.left, rect.bottom-rect.top,
		NULL, NULL, hInstance, NULL
	);
	ShowWindow(hwnd, nCmdshow);
	UpdateWindow(hwnd);
	while (1) {
		MSG msg = { 0 };
		if (PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		if (msg.message == WM_QUIT)break;
		//�õ��豸���������
		HDC hdc = GetDC(hwnd);
		//����
		hpen = CreatePen(1, 3, RGB(rand()%256,rand()%256,rand()%256));
		SelectObject(hdc, hpen);
		MoveToEx(hdc, 0, 0, NULL);
		LineTo(hdc, 640, 480);
		DeleteObject(hpen);
		//����һ��������
		hbrush = CreateHatchBrush(0, RGB(255, 0, 0));
		hpen = CreatePen(1, 1, RGB(0, 0, 0));
		SelectObject(hdc, hbrush);
		SelectObject(hdc, hpen);
		POINT poly[3] = { { 100,100 },{ 600,200 },{ 200,300 } };
		Polygon(hdc, &poly[0], 3);
		DeleteObject(hbrush);
		DeleteObject(hpen);
		//����һ����ɫ���ޱ߿����
		hbrush = CreateSolidBrush(RGB(0, 255, 0));
		SelectObject(hdc, hbrush);
		SelectObject(hdc, hnullpen);
		Rectangle(hdc, 300, 100, 400, 200);
		DeleteObject(hbrush);
		//����Բ
		hpen = CreatePen(0, 5, RGB(0, 0, 255));
		SelectObject(hdc, hpen);
		SelectObject(hdc, hnullbrush);
		Ellipse(hdc, 350 - 50, 150 - 20, 350 + 50, 150 + 20);
		DeleteObject(hpen);
		//�û������һ���Ƚ���ֵ�Բ
		for(int i=-50; i<=50; ++i)
			for (int j = -50; j <= 50; ++j)if ((i * i + j * j <= 50 * 50) && (((i>>1)^(j>>1)) & 1))
				SetPixel(hdc, 50 + i, 300 + j, RGB(255, 0, 255));
		//�ͷ�DC
		ReleaseDC(hwnd, hdc);
		Sleep(1);
	}
}