﻿//
//	easypaint.h
//	ST_PUZZLE
//
//	Created by Eden,Pjy on 5/2/18.
//	Copyright © 2018年 author. All rights reserved.
//
//
//	用Visual Studio 2017编译之前注意事项：
//	文件属性->c/c++->预处理器->预处理器定义 中添加：
//	_CRT_SECURE_NO_DEPRECATE
//	_CRT_NONSTDC_NO_DEPRECATE
//	文件属性->c/c++->代码生成->运行库 修改为 "多线程调试 (/MTd)"
//
#pragma once
#include <windows.h>
#include <conio.h>
#include <graphics.h>
#include <vector>
#include <utility>
#include <cstdlib>
#include <ctime>
#include <string>
#include <iostream>
using namespace std;
typedef pair<int, int> PII;
/*
createg(int x,int y):
create a x*y window
closeg():
close a window
delay(int t):
sleep(t): lower the cpu utilization
setc(int c):
set color of a line(including edge of shapes)
sett(int height,int width,char *font)
width: 0:default
color:
BLACK		DARKGRAY
BLUE		LIGHTBLUE
GREEN		LIGHTGREEN
CYAN		LIGHTCYAN
RED			LIGHTRED
MAGENTA		LIGHTMAGENTA
BROWN		YELLOW
LIGHTGRAY	WHITE
setl(int s,int t):
set style of a line(including edge of shapes)
s(0~4):define the style of a line
t:define the thickness of a line
settc(int c):
set color of text
setfc(int c):
set color of a filled shape
pline(int x1,int y1,int x2,int y2):
paint a line from (x1,y1) to (x2,y2)
dcircle(int x,int y,int r):
draw the edges of a circle
fcircle(int x,int y,int r):
fill a circle
dbar(int x1,int y1,int x2,int y2):
draw the edges of a rectangle
fbar(int x1,int y1,int x2,int y2):
fill a rectangle
dellipse(int x,int y,int r1,int r2)
fellipse(int x,int y,int r1,int r2)
pdot(int x,int y,int c)
put a pixel of color c
beginpaint:
flushpaint:
endpaint:
start paint only when "flushpaint" or "end paint"
readkey:
read until one key is pressed
readkeypressed:
read the current key
readasynckey(nkey):
0		---not pressed before; not pressed now;
1		---pressed before; not pressed now
-32768	---not pressed before; pressed now
-32767	---pressed before; pressed now
*/
void mkdir(const char* s) { CreateDirectory(s, NULL); }
bool mkfile(const char* s) {
	FILE *f = fopen(s, "r"); bool res = 0;
	if (f == NULL) f = fopen(s, "wt+"), res = 1;
	fclose(f); return res;
}
#define rgb(a,b,c) RGB(a,b,c)
#define sqr(x) ((x)*(x))
void createg(int x, int y) { initgraph(x, y); }
void closeg() { closegraph(); }
void delay(int t) { Sleep(t); }
void setc(int c) { setlinecolor(c); }
void setl(int s, int t) { setlinestyle(s, t); }
void settc(int c) { settextcolor(c); }
void setfc(int c) { setfillcolor(c); }
void setbkd(int d) { setbkmode(d); }
void setbkc(int c) { setbkcolor(c); }
void sett(int height, int width) { settextstyle(height, width, ""); }
void sett(int height, int width, char *font) { settextstyle(height, width, font); }
struct spline {
	int s, t, c;
	int x1, y1, x2, y2;
	spline() {}
	spline(int S, int T, int C, int X1, int Y1, int X2, int Y2) {
		s = S; t = T; c = C; x1 = X1; y1 = Y1; x2 = X2; y2 = Y2;
	}
};
void pline(int x1, int y1, int x2, int y2) { line(x1, y1, x2, y2); }
void pline(spline s) {
	int c = getlinecolor(); LINESTYLE t; getlinestyle(&t);
	setlinecolor(s.c); setlinestyle(s.s, s.t);
	line(s.x1, s.y1, s.x2, s.y2);
	setlinecolor(c); setlinestyle(&t);
}
struct sdcircle {
	int s, t, c;
	int x, y, r;
	sdcircle() {}
	sdcircle(int S, int T, int C, int X, int Y, int R) {
		s = S; t = T; c = C; x = X; y = Y; r = R;
	}
};
void dcircle(int x, int y, int r) { circle(x, y, r); }
void dcircle(sdcircle s) {
	int c = getlinecolor(); LINESTYLE t; getlinestyle(&t);
	setlinecolor(s.c); setlinestyle(s.s, s.t);
	circle(s.x, s.y, s.r);
	setlinecolor(c); setlinestyle(&t);
}
struct sfcircle {
	int c;
	int x, y, r;
	sfcircle() {}
	sfcircle(int C, int X, int Y, int R) {
		c = C; x = X; y = Y; r = R;
	}
};
void fcircle(int x, int y, int r) { solidcircle(x, y, r); }
void fcircle(sfcircle s) {
	int c = getfillcolor();
	setfillcolor(s.c);
	solidcircle(s.x, s.y, s.r);
	setfillcolor(c);
}
struct sdbar {
	int s, t, c;
	int x1, y1, x2, y2;
	sdbar() {}
	sdbar(int S, int T, int C, int X1, int Y1, int X2, int Y2) {
		s = S; t = T; c = C; x1 = X1; y1 = Y1; x2 = X2; y2 = Y2;
	}
};
void dbar(int x1, int y1, int x2, int y2) { rectangle(x1, y1, x2, y2); }
void dbar(sdbar s) {
	int c = getlinecolor(); LINESTYLE t; getlinestyle(&t);
	setlinecolor(s.c); setlinestyle(s.s, s.t);
	rectangle(s.x1, s.y1, s.x2, s.y2);
	setlinecolor(c); setlinestyle(&t);
}
struct sfbar {
	int c;
	int x1, y1, x2, y2;
	sfbar() {}
	sfbar(int C, int X1, int Y1, int X2, int Y2) {
		c = C; x1 = X1; y1 = Y1; x2 = X2; y2 = Y2;
	}
};
void fbar(int x1, int y1, int x2, int y2) { solidrectangle(x1, y1, x2, y2); }
void fbar(sfbar s) {
	int c = getfillcolor();
	setfillcolor(s.c);
	solidrectangle(s.x1, s.y1, s.x2, s.y2);
	setfillcolor(c);
}
struct sdellipse {
	int s, t, c;
	int x, y, r1, r2;
	sdellipse() {}
	sdellipse(int S, int T, int C, int X, int Y, int R1, int R2) {
		s = S; t = T; c = C; x = X; y = Y; r1 = R1; r2 = R2;
	}
};
void dellipse(int x, int y, int r1, int r2) { ellipse(x, y, r1, r2); }
void dellipse(sdellipse s) {
	int c = getlinecolor(); LINESTYLE t; getlinestyle(&t);
	setlinecolor(s.c); setlinestyle(s.s, s.t);
	ellipse(s.x, s.y, s.r1, s.r2);
	setlinecolor(c); setlinestyle(&t);
}
struct sfellipse {
	int c;
	int x, y, r1, r2;
	sfellipse() {}
	sfellipse(int C, int X, int Y, int R1, int R2) {
		c = C; x = X; y = Y; r1 = R1; r2 = R2;
	}
};
void fellipse(int x, int y, int r1, int r2) { solidellipse(x, y, r1, r2); }
void fellipse(sfellipse s) {
	int c = getfillcolor();
	setfillcolor(s.c);
	solidellipse(s.x, s.y, s.r1, s.r2);
	setfillcolor(c);
}
struct spdot {
	int c, x, y;
	spdot() {}
	spdot(int C, int X, int Y) {
		c = C; x = X; y = Y;
	}
};
void pdot(int x, int y, int c) { putpixel(x, y, c); }
void pdot(spdot s) {
	putpixel(s.x, s.y, s.c);
}
char *constr(const char *S) {
	return const_cast<char*>(S);
}
string constr(int s) {
	if (s < 0)return "-" + constr(-s);
	if (s<10)return (string)((string)("") + char(s + 48));
	return constr(s / 10) + char(s % 10 + 48);
}
struct sptext {
	int c, bkd, bkc;
	int x, y, h, w; char *font, *str;
	sptext() {}
	sptext(int H, int W, const char *Font, int C, int Bkd, int Bkc, int X, int Y, const char *Str) {
		h = H; w = W; font = constr(Font); c = C; bkd = Bkd; bkc = Bkc; x = X; y = Y; str = constr(Str);
	}
	sptext(int H, int W, const char *Font, int C, int X, int Y, const char *Str) {
		h = H; w = W; font = constr(Font); c = C; bkd = TRANSPARENT; bkc = 0; x = X; y = Y; str = constr(Str);
	}
	sptext(int H, int W, int C, int Bkd, int Bkc, int X, int Y, const char *Str) {
		h = H; w = W; font = NULL; c = C; bkd = Bkd; bkc = Bkc; x = X; y = Y; str = constr(Str);
	}
	sptext(int H, int W, int C, int X, int Y, const char *Str) {
		h = H; w = W; font = NULL; c = C; bkd = TRANSPARENT; bkc = 0; x = X; y = Y; str = constr(Str);
	}
};
void ptext(int x, int y, const char *str) {
	int D = getbkmode();
	setbkmode(TRANSPARENT); outtextxy(x, y, str);
	setbkmode(D);
}
void ptext(sptext s) {
	int c = gettextcolor(), D = getbkmode(), C = getbkcolor(); LOGFONT font; gettextstyle(&font);
	settextcolor(s.c); setbkmode(s.bkd); setbkcolor(s.bkc); settextstyle(s.h, s.w, s.font);
	outtextxy(s.x, s.y, s.str);
	settextcolor(c); setbkmode(D); setbkcolor(C); settextstyle(&font);
}
void beginpaint() { BeginBatchDraw(); }
void flushpaint() { FlushBatchDraw(); }
void endpaint() { EndBatchDraw(); }
void flushkey() { FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE)); }
char readkey() { return getch(); }
char readkeypressed() { if (kbhit())return getch(); else return NULL; }
int readasynckey(int nkey) { return GetAsyncKeyState(nkey); }
void flushmouse() { FlushMouseMsgBuffer(); }
MOUSEMSG readmouse() { return GetMouseMsg(); }
POINT readmousexy() {
	HWND hwnd = GetHWnd();
	POINT point;
	GetCursorPos(&point);
	ScreenToClient(hwnd, &point);
	return point;
}
struct vector2 {
	double x, y;
	vector2() {}
	vector2(double X, double Y) { x = X; y = Y; }
};
double norm(vector2 p) {
	return sqrt(p.x*p.x + p.y*p.y);
}
vector2 operator+(vector2 a, vector2 b) {
	return vector2(a.x + b.x, a.y + b.y);
}
vector2 operator-(vector2 a, vector2 b) {
	return vector2(a.x - b.x, a.y - b.y);
}
vector2 operator*(vector2 a, double s) {
	return vector2(a.x*s, a.y*s);
}
spline operator+(spline a, vector2 b) {
	spline A = a; int x = (int)b.x, y = (int)b.y;
	A.x1 += x; A.x2 += x; A.y1 += y; A.y2 += y; return A;
}
sdcircle operator+(sdcircle a, vector2 b) {
	sdcircle A = a; int x = (int)b.x, y = (int)b.y;
	A.x += x; A.y += y; return A;
}
sfcircle operator+(sfcircle a, vector2 b) {
	sfcircle A = a; int x = (int)b.x, y = (int)b.y;
	A.x += x; A.y += y; return A;
}
sdbar operator+(sdbar a, vector2 b) {
	sdbar A = a; int x = (int)b.x, y = (int)b.y;
	A.x1 += x; A.x2 += x; A.y1 += y; A.y2 += y; return A;
}
sfbar operator+(sfbar a, vector2 b) {
	sfbar A = a; int x = (int)b.x, y = (int)b.y;
	A.x1 += x; A.x2 += x; A.y1 += y; A.y2 += y; return A;
}
sdellipse operator+(sdellipse a, vector2 b) {
	sdellipse A = a; int x = (int)b.x, y = (int)b.y;
	A.x += x; A.y += y; return A;
}
sfellipse operator+(sfellipse a, vector2 b) {
	sfellipse A = a; int x = (int)b.x, y = (int)b.y;
	A.x += x; A.y += y; return A;
}
spdot operator+(spdot a, vector2 b) {
	spdot A = a; int x = (int)b.x, y = (int)b.y;
	A.x += x; A.y += y; return A;
}
sptext operator+(sptext a, vector2 b) {
	sptext A = a; int x = (int)b.x, y = (int)b.y;
	A.x += x; A.y += y; return A;
}

class figure {
public:
	vector <spline> S1;
	vector <sdcircle> S2;
	vector <sfcircle> S3;
	vector <sdbar> S4;
	vector <sfbar> S5;
	vector <sdellipse> S6;
	vector <sfellipse> S7;
	vector <spdot> S8;
	vector <sptext> S9;
	vector <PII> S;
	figure() {
		S1.clear(); S2.clear(); S3.clear();
		S4.clear(); S5.clear(); S6.clear();
		S7.clear(); S8.clear(); S9.clear();
		S.clear();
	}
	void clear() {
		S1.clear(); S2.clear(); S3.clear();
		S4.clear(); S5.clear(); S6.clear();
		S7.clear(); S8.clear(); S9.clear();
		S.clear();
	}
	void insert(spline a) {
		S1.push_back(a);
		S.push_back(make_pair(1, S1.size() - 1));
	}
	void insert(sdcircle a) {
		S2.push_back(a);
		S.push_back(make_pair(2, S2.size() - 1));
	}
	void insert(sfcircle a) {
		S3.push_back(a);
		S.push_back(make_pair(3, S3.size() - 1));
	}
	void insert(sdbar a) {
		S4.push_back(a);
		S.push_back(make_pair(4, S4.size() - 1));
	}
	void insert(sfbar a) {
		S5.push_back(a);
		S.push_back(make_pair(5, S5.size() - 1));
	}
	void insert(sdellipse a) {
		S6.push_back(a);
		S.push_back(make_pair(6, S6.size() - 1));
	}
	void insert(sfellipse a) {
		S7.push_back(a);
		S.push_back(make_pair(7, S7.size() - 1));
	}
	void insert(spdot a) {
		S8.push_back(a);
		S.push_back(make_pair(8, S8.size() - 1));
	}
	void insert(sptext a) {
		S9.push_back(a);
		S.push_back(make_pair(9, S9.size() - 1));
	}
	void paint(vector2 pos = vector2(0, 0)) {
		if (S.empty())return;
		for (int i = 0; i<(int)S.size(); ++i) {
			switch (S[i].first) {
			case 1:pline(S1[S[i].second] + pos); break;
			case 2:dcircle(S2[S[i].second] + pos); break;
			case 3:fcircle(S3[S[i].second] + pos); break;
			case 4:dbar(S4[S[i].second] + pos); break;
			case 5:fbar(S5[S[i].second] + pos); break;
			case 6:dellipse(S6[S[i].second] + pos); break;
			case 7:fellipse(S7[S[i].second] + pos); break;
			case 8:pdot(S8[S[i].second] + pos); break;
			case 9:ptext(S9[S[i].second] + pos); break;
			}
		}
	}
	void paint(int x, int y) {
		paint(vector2(x, y));
	}
};
